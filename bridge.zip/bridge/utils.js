// @flow

'use strict';

import { Platform } from 'react-native';

export const isIOS = Platform.OS === 'ios';
export const isAndroid = Platform.OS === 'android';

export const forceExec = (
  moduleIOS: Object,
  moduleAndroid: Object,
  methodName: string,
  args: Array<mixed>
): any => {
  if (isIOS) {
    return moduleIOS[methodName](...args);
  } else if (isAndroid) {
    return moduleAndroid[methodName](...args);
  }
};

export const unsupportedMethodException = (): Promise<Object> => {
  const msg = 'Not supported yet';

  console.warn(msg);
  return Promise.reject({ message: msg });
};

export const decodeJWTToken = (token) => {
  try {
    // if the token has more or less than 3 parts or is not a string
    // then is not a valid token
    if (token.split('.').length !== 3 || typeof token !== 'string') {
      return null;
    }

    // payload ( index 1 ) has the data stored and
    // data about the expiration time
    const payload = token.split('.')[1];
    // handle unicode parsing issues between atob and JWT base64 format
    const base64 = payload.replace('-', '+').replace('_', '/');
    // return decoded and parsed to json
    return JSON.parse(atob(base64));
  } catch (error) {
    // Return null if something goes wrong
    return null;
  }
};

export const getCookie = (name) => {
  return document.cookie
    .split('; ')
    .find((row) => row.startsWith(`${name}=`))
    .split('=')[1];
};

export const getSfApiVersion = () => 'v50.0';
