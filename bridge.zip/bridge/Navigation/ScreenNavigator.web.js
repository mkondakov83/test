// @flow

import { NavigationActions } from './NavigationActions';
import { unsupportedMethodException } from "../utils";

class ScreenNavigator {
  getTabsInfo(): Promise<Array<Object>> {
    return unsupportedMethodException();
  }

  openTab(name: string): Promise<Object> {
    return unsupportedMethodException();
  }

  openDeeplink(path: string): Promise<Object> {
    return unsupportedMethodException();
  }

  dispatch(actions: NavigationActions): Promise<Object> {
    return unsupportedMethodException();
  }
}

export const navigator: ScreenNavigator = new ScreenNavigator();
