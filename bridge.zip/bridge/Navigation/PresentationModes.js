// @flow

export const PRESENT = 'present';
export const PUSH = 'push';
