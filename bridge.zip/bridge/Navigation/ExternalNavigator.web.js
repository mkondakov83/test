// @flow

import { NativeModules } from 'react-native';
import { unsupportedMethodException } from "../utils";

class ExternalNavigator {
  open(url: string): Promise<Object> {
    return unsupportedMethodException();
  }
}

export const externalNavigator: ExternalNavigator = new ExternalNavigator();
