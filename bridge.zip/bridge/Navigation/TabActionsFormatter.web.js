// @flow

import { TabActions, QueryParameters } from './TabActions';
import {unsupportedMethodException} from "../utils";

class TabActionsFormatter {
  navigationPath(actions: TabActions, parameters: QueryParameters): string {
    unsupportedMethodException();
    return "";
  }

  makeParameters(parameters: QueryParameters): string {
    let queries = [this.makeParameter('uid', parameters.uid)];

    parameters.productIDs.forEach((productID) => {
      queries.push(this.makeParameter('product-id', productID));
    });

    return queries.filter(Boolean).join('&');
  }

  makeComponent(key: string, value: string): string {
    if (value == null || value == '') {
      return '';
    }

    return key + '/' + value;
  }

  makeParameter(key: string, value: string): string {
    if (value == null || value == '') {
      return '';
    }

    return key + '=' + value;
  }
}

export const tabFormatter: TabActionsFormatter = new TabActionsFormatter();
