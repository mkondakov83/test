import { NativeModules } from 'react-native';

NativeModules.ExternalNavigatorBridge = {
  open: jest.fn(),
};

export const externalNavigator = {
  open: jest.fn(),
};
