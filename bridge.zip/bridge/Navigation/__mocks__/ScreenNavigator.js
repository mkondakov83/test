import { NativeModules } from 'react-native';

NativeModules.TabItemsFlowHandler = {
  tavItems: jest.fn(),
  navigate: jest.fn(),
};

NativeModules.FlowHandler = {
  navigateToNew: jest.fn(),
  navigateToDetails: jest.fn(),
};

export const navigator = {
  openTab: jest.fn(),
  openDeeplink: jest.fn(),
  dispatch: jest.fn(),
};
