// @flow

export const NEW_MODE = 'new';
export const VIEW_MODE = 'view';
export const EDIT_MODE = 'edit';
