import './__mocks__/LayoutBridge';
import './__mocks__/RNDocumentPicker';
import './__mocks__/RNVectorIconsManager';

jest.mock('./Database/DatabaseManager.native');
jest.mock('./DataUpdates/DataUpdates.native.js');
jest.mock('./EnvironmentData/EnvironmentData.native');
jest.mock('./FileViewer/FileViewerBridge.native.js');
jest.mock('./Localization/localization.native');
jest.mock('./Location/LocationManager.native.js');
jest.mock('./Logger/logger');
jest.mock('./MetadataUpdates/MetadataUpdates.native.js');
jest.mock('./Navigation/ExternalNavigator');
jest.mock('./Navigation/ScreenNavigator');
jest.mock('./sf/sfnetapi');
jest.mock('./ViewState/ViewState.native.js');
jest.mock('./VisionService/VisionServiceBridge.native.js');
