import { NativeModules } from 'react-native';

NativeModules.ViewStateBridge = {};

export const viewStateBridge = {
  addViewStateListener: jest.fn(),
  removeViewStateListener: jest.fn(),
};
