// @flow

import { unsupportedMethodException } from "../utils";

class ViewStateBridge {

  addViewStateListener(callback: function): Promise<Object> {
    return unsupportedMethodException();
  }

  removeViewStateListener(listener: any): Promise<Object> {
    return unsupportedMethodException();
  }
}

export const viewStateBridge: ViewStateBridge = new ViewStateBridge();
