import { unsupportedMethodException } from '../utils';

class LocationManager {

  lastKnownLocation(): Promise<Object> {
    return unsupportedMethodException();
  }

  getLocationStatus(): Promise<Object> {
    return unsupportedMethodException();
  }

  addLocationListener(callback: function): Promise<Object> {
    return unsupportedMethodException();
  }

  removeLocationListener(listener): Promise<Object> {
    return unsupportedMethodException();
  }
}

export const locationManager: LocationManager = new LocationManager();
