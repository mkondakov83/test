import { NativeModules } from 'react-native';

NativeModules.LocationBridge = {
  deviceLastKnownLocation: jest.fn(),
  getLocationStatus: jest.fn(),
};

export const locationManager = {
  lastKnownLocation: jest.fn(),
  getLocationStatus: jest.fn(),
  addLocationListener: jest.fn(),
  removeLocationListener: jest.fn(),
};
