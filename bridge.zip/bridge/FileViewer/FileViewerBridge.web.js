// @flow

import { unsupportedMethodException } from "../utils";

class FileViewerBridge {
  viewAttachment(attachmentId: string): Promise<Object> {
    return unsupportedMethodException();
  }
}

export const fileViewerBridge: FileViewerBridge = new FileViewerBridge();
