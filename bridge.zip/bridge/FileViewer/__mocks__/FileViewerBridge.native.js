import { NativeModules } from 'react-native';

NativeModules.FileViewerBridge = {
  viewAttachment: jest.fn(),
};

export const fileViewerBridge = {
  viewAttachment: jest.fn(),
};
