// @flow

import { unsupportedMethodException, getSfApiVersion } from '../utils';
import { jwtToken } from '../jwtToken';

class SFNetAPI {
  sfApiVersion = '';
  usePromises = true;
  clientParams = {};

  constructor() {
    this.sfApiVersion = getSfApiVersion();
    this.clientParams = jwtToken.params.client;
  }

  enablePromises() {
    this.usePromises = true;
  }

  /*
   * Lists the available objects and their metadata for your organization's
   * data.
   */
  describeGlobal() {
    return jwtToken.jsforceConnection.describeGlobal();
  }

  /*
   * Describes the individual metadata for the specified object.
   * @param objtype object type; e.g. "Account"
   */
  async metadata(objtype) {
    const response = await fetch(
      `${this.clientParams.instanceUrl}/services/data/${this.sfApiVersion}/sobjects/${objtype}`,
      {
        headers: {
          mode: 'no-cors',
          Authorization: `Bearer ${this.clientParams.oauthToken}`,
        },
      }
    );
    return response.json();
  }

  /*
   * Completely describes the individual metadata at all levels for the
   * specified object.
   * @param objtype object type; e.g. "Account"
   */
  async describe(objtype) {
    const response = await fetch(
      `${this.clientParams.instanceUrl}/services/data/${this.sfApiVersion}/sobjects/${objtype}/describe`,
      {
        headers: {
          mode: 'no-cors',
          Authorization: `Bearer ${this.clientParams.oauthToken}`,
        },
      }
    );
    return response.json();
  }

  /*
   * Fetches the layout configuration for a particular sobject type and record type id.
   * @param objtype object type; e.g. "Account"
   * @param (Optional) recordTypeId Id of the layout's associated record type
   */
  async describeLayout(objtype, recordTypeId) {
    recordTypeId = recordTypeId ? recordTypeId : '';
    const response = await fetch(
      `${this.clientParams.instanceUrl}/services/data/${this.sfApiVersion}/sobjects/${objtype}/describe/layouts/${recordTypeId}`,
      {
        headers: {
          mode: 'no-cors',
          Authorization: `Bearer ${this.clientParams.oauthToken}`,
        },
      }
    );
    return response.json();
  }

  /*
   * Creates a new record of the given type.
   * @param objtype object type; e.g. "Account"
   * @param fields an object containing initial field names and values for
   *               the record, e.g. {:Name "salesforce.com", :TickerSymbol
   *               "CRM"}
   */
  create(objtype, fields) {
    return jwtToken.jsforceConnection.sobject(objtype).create(fields);
  }

  /*
   * Retrieves field values for a record of the given type.
   * @param objtype object type; e.g. "Account"
   * @param id the record's object ID
   * @param [fields=null] optional comma-separated list of fields for which
   *               to return values; e.g. Name,Industry,TickerSymbol
   */
  async retrieve(objtype, id, fields = null) {
    const response = await fetch(
      `${this.clientParams.instanceUrl}/services/data/${this.sfApiVersion}/sobjects/${objtype}/${id}`,
      {
        headers: {
          mode: 'no-cors',
          Authorization: `Bearer ${this.clientParams.oauthToken}`,
        },
      }
    );
    return response.json();
  }

  /*
   * Upsert - creates or updates record of the given type, based on the
   * given external Id.
   * @param objtype object type; e.g. "Account"
   * @param externalIdField external ID field name; e.g. "accountMaster__c"
   * @param externalId the record's external ID value
   * @param fields an object containing field names and values for
   *               the record, e.g. {:Name "salesforce.com", :TickerSymbol
   *               "CRM"}
   */
  upsert(objtype, externalIdField, externalId, fields) {
    return jwtToken.jsforceConnection
      .sobject(objtype)
      .upsert({ Id: externalId, ...fields }, externalIdField);
  }

  /*
   * Updates field values on a record of the given type.
   * @param objtype object type; e.g. "Account"
   * @param id the record's object ID
   * @param fields an object containing initial field names and values for
   *               the record, e.g. {:Name "salesforce.com", :TickerSymbol
   *               "CRM"}
   */
  update(objtype, id, fields) {
    return jwtToken.jsforceConnection.sobject(objtype).update({
      Id: id,
      ...fields,
    });
  }

  /*
   * Deletes a record of the given type. Unfortunately, 'delete' is a
   * reserved word in JavaScript.
   * @param objtype object type; e.g. "Account"
   * @param id the record's object ID
   */
  del(objtype, id, callback, error) {
    // Single record deletion
    return jwtToken.jsforceConnection.sobject(objtype).destroy(id);
  }

  /*
   * Executes the specified SOQL query.
   * @param soql a string containing the query to execute - e.g. "SELECT Id,
   *             Name from Account ORDER BY Name LIMIT 20"
   */
  query(soql) {
    return jwtToken.jsforceConnection.query(soql);
  }

  /*
   * Queries the next set of records based on pagination.
   * <p>This should be used if performing a query that retrieves more than can be returned
   * in accordance with http://www.salesforce.com/us/developer/docs/api_rest/Content/dome_query.htm</p>
   * @param url - the url retrieved from nextRecordsUrl or prevRecordsUrl
   */

  queryMore(locator) {
    // $FlowIgnore
    // const pathFromUrl = url.match(/https:\/\/[^/]*(.*)/)[1];
    return jwtToken.jsforceConnection.queryMore(locator);
  }

  /*
   * Executes the specified SOSL search.
   * @param sosl a string containing the search to execute - e.g. "FIND
   *             {needle}"
   */
  search(sosl) {
    return jwtToken.jsforceConnection.search(sosl);
  }

  /*
   * Merges few requests to one composite request
   * @param requests Array of subrequests to execute.
   * @param refIds Array of reference id for the requests (should have the same number of element than requests)
   * @param allOrNone Specifies what to do when an error occurs while processing a subrequest.
   * @see https://developer.salesforce.com/docs/atlas.en-us.api_rest.meta/api_rest/resources_composite_composite.htm
   */
  composite(requests, refIds, allOrNone, callback, error) {
    return unsupportedMethodException();
  }

  /*
   * Runs apex request
   * @param method sets the http method
   * @param endPoint sets the path ending
   */
  apexRest(method, endPoint, params) {
    return jwtToken.jsforceConnection.apex[method](endPoint, params);
  }

  /*
   * Gets the report by id
   * @param reportId sets the id of report
   */

  async report(reportId) {
    const response = await fetch(
      `${this.clientParams.instanceUrl}/services/data/${this.sfApiVersion}/analytics/reports/${reportId}`,
      {
        headers: {
          mode: 'no-cors',
          Authorization: `Bearer ${this.clientParams.oauthToken}`,
        },
      }
    );
    return response.json();
  }
}

export const sfNetAPI = new SFNetAPI();
