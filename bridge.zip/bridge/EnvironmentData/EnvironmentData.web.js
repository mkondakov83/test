// @flow

import { jwtToken } from '../jwtToken';

interface IData {
  namespace: string;
  userId: string;
  userName: string;
  profileId: string;
  profileName: string;
  timeZone: string;
  locale: string;
  language: string;
  currencyISOCode: string;
  sfInstanceURL: string;
  territory: Object;
  organizationId: string;
  applicationId: string;
  applicationVersionId: string;
  applicationName: string;
}

class EnvironmentData {
  data: IData;

  constructor() {
    this._updateData();
  }

  getEnvironmentData(): IData {
    try {
      const { namespace, territory, applicationId, applicationVersionId, applicationName, profileName } = jwtToken.params.context.environment.parameters;
      const { currencyISOCode, language, locale, timeZone, userId, profileId, userName } = jwtToken.params.context.user;
      const { organizationId } = jwtToken.params.context.organization;
      const sfInstanceURL = jwtToken.params.client.instanceUrl;

      return {
        namespace,
        userId,
        profileId,
        organizationId,
        timeZone,
        locale,
        language,
        currencyISOCode,
        sfInstanceURL,
        territory,
        applicationId,
        applicationVersionId,
        applicationName,
        profileName,
        userName
      };
    } catch (error) {
      console.log(error);
    }
  }

  _updateData():void {
    this.data = this.getEnvironmentData();
  }

  enablePromises() {
    return;
  }

  namespace(): string {
    return this.data.namespace;
  }

  userID(): string {
    console.warn('The "userID" method is deprecated and will be removed. Please use "userId" instead.');
    return this.data.userId;
  }

  userId(): string {
    return this.data.userId;
  }

  profileId(): string {
    return this.data.profileId;
  }

  organizationId(): string {
    return this.data.organizationId;
  }

  timeZone(): string {
    return this.data.timeZone;
  }

  locale(): string {
    return this.data.locale;
  }

  language(): string {
    return this.data.language;
  }

  currencyISOCode(): string {
    return this.data.currencyISOCode;
  }

  sfInstanceURL(): string {
    return this.data.sfInstanceURL;
  }

  //sfApiVersion value hardcoded on mobile in the SalesforceApi.swift
  sfApiVersion(): string {
    return 'v50.0';
  }

  territory(): Object {
    return this.data.territory;
  }

  applicationId(): string {
    return this.data.applicationId;
  }

  applicationVersionId(): string {
    return this.data.applicationVersionId;
  }

  applicationName(): string {
    return this.data.applicationName;
  }

  profileName(): string {
    return this.data.profileName;
  }

  userName(): string {
    return this.data.userName;
  }

  getInitialParams():Object {
    const {applicationId, applicationVersionId, applicationName} = this.data;

    return {
      applicationId,
      applicationVersionId,
      applicationName
    }
  }
}

export const environment: EnvironmentData = new EnvironmentData();

export const initialParams = environment.getInitialParams();
