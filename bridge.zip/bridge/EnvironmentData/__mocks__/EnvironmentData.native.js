import { NativeModules } from 'react-native';

NativeModules.EnvironmentDataBridge = {
  userID: '',
  timeZone: '',
  locale: '',
  language: '',
  currencyISOCode: '',
  sfInstanceURL: '',
  sfApiVersion: '',
  territory: '',
  namespace: '',
};

export const environment = {
  userID: jest.fn(),
  timeZone: jest.fn(),
  locale: jest.fn(),
  language: jest.fn(),
  currencyISOCode: jest.fn(),
  sfInstanceURL: jest.fn(),
  sfApiVersion: jest.fn(),
  territory: jest.fn(),
  namespace: jest.fn(),
};
