import { getCookie, decodeJWTToken } from "./utils";
import jsforce from 'jsforce/build/jsforce';

class JwtToken {
    params = null;
    jsforceConnection= null;

    constructor() {
        this.init();
    }

    init() {
        const encodedJWT = getCookie('jwtToken');
        this.updateParams(decodeJWTToken(encodedJWT));
        //this.params = decodeJWTToken(encodedJWT);
        const { instanceUrl, oauthToken } = this.params.client;
        console.log(this.params);

        if (this.params) {
            this.jsforceConnection = new jsforce.Connection({
                instanceUrl: instanceUrl,
                accessToken: oauthToken,
            });
        }
    }

    updateParams(context) {
      this.params = context;
    }
}

export const jwtToken = new JwtToken();
