import { NativeModules } from 'react-native';

NativeModules.LayoutBridge = {
  setHeight: jest.fn(),
  setSupportedOrientationsForIPhone: jest.fn(),
  closeApp: jest.fn(),
};
