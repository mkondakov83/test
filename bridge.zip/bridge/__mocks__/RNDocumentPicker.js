import { NativeModules } from 'react-native';

NativeModules.RNDocumentPicker = {}
