import { NativeModules } from 'react-native';

NativeModules.VisionServiceBridge = {
  scanBarcode: jest.fn(),
  scanDocument: jest.fn(),
  detectObjects: jest.fn(),
};

export const visionServiceBridge = {
  scanBarcode: jest.fn(),
  scanDocument: jest.fn(),
  detectObjects: jest.fn(),
};
