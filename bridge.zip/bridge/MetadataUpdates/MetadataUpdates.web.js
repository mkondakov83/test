// @flow

import { unsupportedMethodException } from "../utils";

class MetadataUpdatesBridge {

  addChangesListener(callback: function): Promise<Object> {
    return unsupportedMethodException();
  }

  removeChangesListener(listener: any): Promise<Object> {
    return unsupportedMethodException();
  }
}

export const metadataUpdatesBridge: MetadataUpdatesBridge =
  new MetadataUpdatesBridge();
