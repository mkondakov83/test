import { NativeModules } from 'react-native';

NativeModules.MetadataUpdatesBridge = {};

export const metadataUpdatesBridge = {
  addChangesListener: jest.fn(),
  removeChangesListener: jest.fn(),
};
