import { NativeModules } from 'react-native';

NativeModules.LocalizationBridge = {};

export const allLocalizationKeys = jest.fn();
export const localized = jest.fn((_, fallback) => fallback);
