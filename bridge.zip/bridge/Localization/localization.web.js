// @flow

import { jwtToken } from '../jwtToken';

class LocalizationData {
  data = undefined;
  usePromises = true;

  async init() {
    try {
      await this.getLocalizationData();
    } catch (error) {
      console.log(error);
    }
  }

  async getLocalizationData() {
    if (!jwtToken.jsforceConnection) {
      throw new Error('jsforce connection must be already initialized');
    }

    const { namespace } = jwtToken.params.context.environment.parameters;
    const { language } = jwtToken.params.context.user;
    const path = namespace
      ? `/${namespace}/LocalizationData?language=${language}`
      : `/LocalizationData?language=${language}`;

    try {
      const data = await jwtToken.jsforceConnection.apex.get(path, {});
      this.data = JSON.parse(data);
    } catch (error) {
      console.error('Failed to retrieve translations: ', error);
    }
  }

  enablePromises() {
    this.usePromises = true;
  }
}

export const localizationData = new LocalizationData();

function allLocalizationKeys(): Array<string> {
  const dataObject = localizationData.data || {};

  return Object.keys(dataObject);
}

function localized(key: string, defaultValue: string): string {
  const dataObject = localizationData.data || {};

  const formattedKey = key.toLowerCase();
  const { namespace } = jwtToken.params.context.environment.parameters;
  const keyWithNamespace = namespace + formattedKey;
  const keyWithLowercaseNamespace = namespace.toLowerCase() + formattedKey;

  return (
    dataObject[key] ||
    dataObject[keyWithNamespace] ||
    dataObject[keyWithLowercaseNamespace] ||
    defaultValue
  );
}

export { allLocalizationKeys, localized };

