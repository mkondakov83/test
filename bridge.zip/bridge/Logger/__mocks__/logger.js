import { NativeModules } from 'react-native';

NativeModules.LoggerBridge = {};

export const iosLogger = {
  getStackTrace: jest.fn(),
  debug: jest.fn(),
  error: jest.fn(),
  warning: jest.fn(),
  info: jest.fn(),
  log: jest.fn(),
};
