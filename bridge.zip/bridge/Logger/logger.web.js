// @flow

import { Logging } from './logging';
import { jwtToken } from '../jwtToken';
import { environment } from '../EnvironmentData/EnvironmentData';

const truncate = (str: string, length: number) => str.slice(0, length);

const logTypeMap = {
  bridgeLogLevelWarning: 'WARN',
  bridgeLogLevelError: 'ERROR',
  bridgeLogLevelInfo: 'WARN',
  bridgeLogLevelDebug: 'WARN',
};

class Logger implements Logging {
  getStackTrace(): Array<string> {
    let stack = new Error().stack;

    const lines = stack.split('\n').map(function (line) {
      return line.trim();
    });

    lines.splice(stack[0] === 'Error' ? 2 : 1, 1, '');

    return lines;
  }

  /**
   * @deprecated
   */
  debug(msg: string, file: string = '') {
    this.warning(msg, file);
  }

  error(msg: string, file: string = '') {
    this.log('bridgeLogLevelError', msg, file);
  }

  warning(msg: string, file: string = '') {
    this.log('bridgeLogLevelWarning', msg, file);
  }

  /**
   * @deprecated
   */
  info(msg: string, file: string = '') {
    this.warning(msg, file);
  }

  log(type: string, msg: string, file: string) {
    const stack = this.getStackTrace();
    const funcName = stack[3];

    // eslint-disable-next-line no-console
    console.log(`${type}: ${msg} ${file} ${funcName}`);

    const namespace = environment.namespace();
    const applicationId = environment.applicationId();
    const applicationVersionId = environment.applicationVersionId();
    const applicationName = environment.applicationName();
    const source = `AppId: ${applicationId}; VersionId: ${applicationVersionId}; AppName: ${applicationName}`;

    jwtToken.jsforceConnection
      .sobject(`${namespace}Log__c`)
      .create({
        [`${namespace}Source__c`]: truncate(source, 255),
        [`${namespace}Level__c`]: logTypeMap[type] ?? '',
        [`${namespace}Message__c`]: truncate(msg, 131072),
        [`${namespace}User__c`]: environment.userID(),
        [`${namespace}Where__c`]: funcName ? `${file ?? ''} ${funcName}` : null,
        [`${namespace}CallStack__c`]: truncate(stack.join(', '), 255),
        [`${namespace}Origin__c`]: null,
      })
      .catch(console.error);
  }
}

export const iosLogger: Logger = new Logger();
