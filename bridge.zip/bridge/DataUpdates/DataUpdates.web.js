//@flow

import { unsupportedMethodException } from '../utils';

class DataUpdatesBridge {

  addDataChangesForSoqlListener(callback: function): Promise<Object> {
    return unsupportedMethodException();
  }

  removeDataChangesForSoqlListener(listener: any): Promise<Object> {
    return unsupportedMethodException();
  }

  startObservingDataChangeForSoql(soql: string): Promise<Object> {
    return unsupportedMethodException();
  }

  stopObservingDataChangeForSoql(soql: string): Promise<Object> {
    return unsupportedMethodException();
  }
}

export const dataUpdatesBridge: DataUpdatesBridge = new DataUpdatesBridge();
