import { NativeModules } from 'react-native';

NativeModules.DataUpdatesBridge = {
  startObservingDataChangeForSoql: jest.fn(),
  stopObservingDataChangeForSoql: jest.fn(),
};

export const dataUpdatesBridge = {
  addDataChangesForSoqlListener: jest.fn(),
  removeDataChangesForSoqlListener: jest.fn(),
  startObservingDataChangeForSoql: jest.fn(),
  stopObservingDataChangeForSoql: jest.fn(),
};
