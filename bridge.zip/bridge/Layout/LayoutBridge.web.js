// @flow

import { unsupportedMethodException } from '../utils';

class LayoutBridge {
  /*
   * Sets height of widget's container view.
   * Works only with widgets.
   * @param height: height in points
   */
  setHeight(height: Number): Promise<Object> {
    return unsupportedMethodException();
  }

  /*
   * Set supported orientations for application.
   * Works only with iPhone/iPod Touch
   * Works only with fullscreen apps
   * @param orientations: string with one of the values: "portrait", "landscape", "allButUpsideDown"
   * @param [error=null] function called in case of error
   */
  setSupportedOrientationsForIPhone(orientations: string): Promise<Object> {
      return unsupportedMethodException();
  }
}

export const layoutBridge: LayoutBridge = new LayoutBridge();
