import { NativeModules } from 'react-native';

NativeModules.DatabaseManager = {
  fetch: jest.fn(),
  upsert: jest.fn(),
  delete: jest.fn(),
};

export const databaseManager = {
  fetch: jest.fn(),
  upsert: jest.fn(),
  delete: jest.fn(),
};
