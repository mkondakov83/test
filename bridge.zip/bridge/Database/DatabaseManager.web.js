// @flow
import { unsupportedMethodException } from '../utils';
import { jwtToken } from '../jwtToken';

export interface DatabaseManagable {
  fetch(sql: string): Promise<Object>;
  upsert(entities: Array<Object>): Promise<Object>;
}

class DatabaseManager implements DatabaseManagable {
  fetch(soql: string): Promise<Object> {
    return jwtToken.jsforceConnection.query(soql);
  }

  upsert(entities: Array<Object>): Promise<Object> {
    return unsupportedMethodException();
  }

  delete(ids: Array<String>): Promise<Object> {
    return unsupportedMethodException();
  }
}

export const databaseManager: DatabaseManagable = new DatabaseManager();
